# Setting up the redesign

## 1. Replace two files in your repo
- `src/index.ts` — overwrite your existing file with this one.
- `public/style.css` — overwrite your existing file with this one.

## 2. Add one new file
- `src/companies-data.ts` — this is new. This is the only file you'll ever
  need to edit to add a company or a job posting — see the comments at
  the top of it.

## 3. Add your images (these are the only two things missing)
- **Hero photo:** add a file named `hero.jpg` to `/public/`. Any wide,
  professional stock/landscape photo works — it auto-crops to fill the
  band at the top of the homepage and has a subtle scroll effect built in.
- **Company logos:** add each company's logo file to `/public/logos/`
  using the exact filename referenced in `companies-data.ts` (e.g.
  `tidehouse.png`). PNG or SVG with a transparent background looks best.
  If a logo file is missing, the site automatically shows the company's
  initials instead — nothing will ever look broken.

## That's it
Commit and push — Vercel redeploys automatically. From then on, adding a
new company or role is a two-minute edit to `companies-data.ts` and
dropping one image file in `/public/logos/`. No other code changes needed.
